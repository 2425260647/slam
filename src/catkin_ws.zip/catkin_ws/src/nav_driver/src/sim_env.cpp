#include <ros/ros.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>
#include <tf2_ros/transform_broadcaster.h>
#include <tf2/LinearMath/Quaternion.h>
#include <cmath>
#include <vector>

class SimEnvironment
{
public:
    SimEnvironment()
    {
        map_.info.resolution = 0.05;
        map_.info.width = 200;
        map_.info.height = 200;
        map_.info.origin.position.x = -5.0;
        map_.info.origin.position.y = -5.0;
        map_.data.resize(map_.info.width * map_.info.height, 0);
        addWall(0, 0, 200, 1);                 // 下墙
        addWall(0, 199, 200, 1);               // 上墙
        addWall(0, 1, 1, 198);                 // 左墙
        addWall(199, 1, 1, 198);               // 右墙
        addWall(70, 70, 20, 5);                // 障碍物1
        addWall(120, 120, 10, 30);             // 障碍物2

        x_ = 0.0; y_ = 0.0; theta_ = 0.0;

        map_pub_ = nh_.advertise<nav_msgs::OccupancyGrid>("/map", 1, true);
        scan_pub_ = nh_.advertise<sensor_msgs::LaserScan>("/scan", 10);
        actual_path_pub_ = nh_.advertise<nav_msgs::Path>("/actual_path", 10);
        object_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/object_detected", 10);
        cmd_sub_ = nh_.subscribe("/cmd_vel", 10, &SimEnvironment::cmdCallback, this);

        map_.header.frame_id = "map";
        map_.header.stamp = ros::Time::now();
        map_pub_.publish(map_);

        object_pose_.header.frame_id = "camera_link";
        object_pose_.pose.position.x = 4.0;   // 相机前 4m
        object_pose_.pose.position.y = 0.0;
        object_pose_.pose.position.z = 0.0;
        object_pose_.pose.orientation.w = 1.0;
        // 延迟 1 秒发布，确保所有 TF 和订阅都就绪
        object_found_timer_ = nh_.createTimer(ros::Duration(1.0), &SimEnvironment::publishObject, this, true);
    }

    void cmdCallback(const geometry_msgs::Twist::ConstPtr& msg)
    {
        double dt = 0.1;
        double v = msg->linear.x;
        double w = msg->angular.z;
        theta_ += w * dt;
        x_ += v * cos(theta_) * dt;
        y_ += v * sin(theta_) * dt;
    }

    void publishTF(const ros::Time& now)
    {
        static tf2_ros::TransformBroadcaster br;
        geometry_msgs::TransformStamped transformStamped;

        // map -> odom (固定)
        transformStamped.header.stamp = now;
        transformStamped.header.frame_id = "map";
        transformStamped.child_frame_id = "odom";
        transformStamped.transform.translation.x = 0;
        transformStamped.transform.translation.y = 0;
        transformStamped.transform.translation.z = 0;
        tf2::Quaternion q;
        q.setRPY(0, 0, 0);
        transformStamped.transform.rotation.x = q.x();
        transformStamped.transform.rotation.y = q.y();
        transformStamped.transform.rotation.z = q.z();
        transformStamped.transform.rotation.w = q.w();
        br.sendTransform(transformStamped);

        // odom -> base_link (模拟运动)
        transformStamped.header.stamp = now;
        transformStamped.header.frame_id = "odom";
        transformStamped.child_frame_id = "base_link";
        transformStamped.transform.translation.x = x_;
        transformStamped.transform.translation.y = y_;
        transformStamped.transform.translation.z = 0;
        q.setRPY(0, 0, theta_);
        transformStamped.transform.rotation.x = q.x();
        transformStamped.transform.rotation.y = q.y();
        transformStamped.transform.rotation.z = q.z();
        transformStamped.transform.rotation.w = q.w();
        br.sendTransform(transformStamped);

        // base_link -> camera_link (固定安装位置)
        transformStamped.header.stamp = now;
        transformStamped.header.frame_id = "base_link";
        transformStamped.child_frame_id = "camera_link";
        transformStamped.transform.translation.x = 0.32;
        transformStamped.transform.translation.y = 0;
        transformStamped.transform.translation.z = 0.3;
        q.setRPY(0, 0, 0);
        transformStamped.transform.rotation.x = q.x();
        transformStamped.transform.rotation.y = q.y();
        transformStamped.transform.rotation.z = q.z();
        transformStamped.transform.rotation.w = q.w();
        br.sendTransform(transformStamped);
    }

    void publishScan(const ros::Time& now)
    {
        sensor_msgs::LaserScan scan;
        scan.header.frame_id = "base_link";
        scan.header.stamp = now;
        scan.angle_min = -M_PI;
        scan.angle_max = M_PI;
        scan.angle_increment = M_PI/180.0;
        scan.range_min = 0.1;
        scan.range_max = 10.0;
        int num_ranges = (scan.angle_max - scan.angle_min) / scan.angle_increment + 1;
        scan.ranges.resize(num_ranges);

        for (int i = 0; i < num_ranges; ++i)
        {
            double angle = scan.angle_min + i * scan.angle_increment;
            double range = scan.range_max;
            for (double r = 0.0; r < scan.range_max; r += map_.info.resolution)
            {
                double px = x_ + r * cos(theta_ + angle);
                double py = y_ + r * sin(theta_ + angle);
                int mx = (px - map_.info.origin.position.x) / map_.info.resolution;
                int my = (py - map_.info.origin.position.y) / map_.info.resolution;
                if (mx < 0 || mx >= map_.info.width || my < 0 || my >= map_.info.height)
                    break;
                if (map_.data[my * map_.info.width + mx] == 100)
                {
                    range = r;
                    break;
                }
            }
            scan.ranges[i] = range;
        }
        scan_pub_.publish(scan);
    }

    void publishActualPath(const ros::Time& now)
    {
        geometry_msgs::PoseStamped pose;
        pose.header.frame_id = "map";
        pose.header.stamp = now;
        pose.pose.position.x = x_;
        pose.pose.position.y = y_;
        pose.pose.position.z = 0;
        tf2::Quaternion q;
        q.setRPY(0, 0, theta_);
        pose.pose.orientation.x = q.x();
        pose.pose.orientation.y = q.y();
        pose.pose.orientation.z = q.z();
        pose.pose.orientation.w = q.w();
        actual_path_.header.frame_id = "map";
        actual_path_.header.stamp = now;
        actual_path_.poses.push_back(pose);
        actual_path_pub_.publish(actual_path_);
    }

    void publishObject(const ros::TimerEvent&)
    {
        object_pose_.header.stamp = ros::Time::now();
        object_pub_.publish(object_pose_);
        ROS_INFO("Simulated object detected at camera_link frame (%.2f m ahead)", object_pose_.pose.position.x);
    }

    void spin()
    {
        ros::Rate rate(10);
        while (ros::ok())
        {
            ros::Time now = ros::Time::now();
            publishTF(now);
            publishScan(now);
            publishActualPath(now);
            ros::spinOnce();
            rate.sleep();
        }
    }

private:
    void addWall(int x, int y, int w, int h)
    {
        for (int i = y; i < y + h && i < map_.info.height; ++i)
            for (int j = x; j < x + w && j < map_.info.width; ++j)
                map_.data[i * map_.info.width + j] = 100;
    }

    ros::NodeHandle nh_;
    ros::Publisher map_pub_, scan_pub_, actual_path_pub_, object_pub_;
    ros::Subscriber cmd_sub_;
    ros::Timer object_found_timer_;
    nav_msgs::OccupancyGrid map_;
    nav_msgs::Path actual_path_;
    geometry_msgs::PoseStamped object_pose_;
    double x_, y_, theta_;
};

int main(int argc, char** argv)
{
    ros::init(argc, argv, "sim_env");
    SimEnvironment sim;
    sim.spin();
    return 0;
}