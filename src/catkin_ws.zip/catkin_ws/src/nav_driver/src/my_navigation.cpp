#include "nav_driver/my_navigation.h"
#include <cmath>
#include <algorithm>

NavigationDriver::NavigationDriver(ros::NodeHandle& nh)
  : nh_(nh)
  , ac_("move_base", true)
  , tf_listener_(tf_buffer_)
  , map_received_(false)
  , object_found_(false)
  , last_object_time_(ros::Time(0))
{
    nh_.param("camera_offset_x", camera_offset_x_, 0.32);
    nh_.param("stop_distance", stop_distance_, 1.0);
    nh_.param("object_timeout", object_timeout_, 5.0);
    nh_.param("exploration_frequency", exploration_frequency_, 0.5);
    nh_.param("frontier_min_dist", frontier_min_dist_, 0.5);

    object_sub_ = nh_.subscribe("/object_detected", 1, &NavigationDriver::objectCallback, this);
    map_sub_ = nh_.subscribe("/map", 1, &NavigationDriver::mapCallback, this);

    ROS_INFO("Waiting for move_base action server...");
    ac_.waitForServer();
    ROS_INFO("Connected to move_base server");

    explore_timer_ = nh_.createTimer(ros::Duration(1.0/exploration_frequency_),
                                     &NavigationDriver::timerCallback, this);
}

NavigationDriver::~NavigationDriver()
{
}

void NavigationDriver::objectCallback(const geometry_msgs::PoseStampedConstPtr& msg)
{
    std::lock_guard<std::mutex> lock(data_mutex_);
    try
    {
        geometry_msgs::PoseStamped pose_map;
        tf_buffer_.transform(*msg, pose_map, "map", ros::Duration(1.0));
        object_pose_map_ = pose_map.pose;
        object_found_ = true;
        last_object_time_ = ros::Time::now();
        ROS_INFO_THROTTLE(1.0, "Object found at map: (%.2f, %.2f)",
                          object_pose_map_.position.x, object_pose_map_.position.y);
    }
    catch (tf2::TransformException &ex)
    {
        ROS_WARN_THROTTLE(5.0, "TF transform failed for object: %s", ex.what());
    }
}

void NavigationDriver::mapCallback(const nav_msgs::OccupancyGridConstPtr& msg)
{
    std::lock_guard<std::mutex> lock(data_mutex_);
    current_map_ = *msg;
    map_received_ = true;
}

void NavigationDriver::timerCallback(const ros::TimerEvent& event)
{
    std::lock_guard<std::mutex> lock(data_mutex_);

    if (object_found_ && (ros::Time::now() - last_object_time_).toSec() > object_timeout_)
    {
        object_found_ = false;
        ROS_WARN("Object signal lost, switching to exploration.");
    }

    if (object_found_)
    {
        ac_.cancelAllGoals();
        geometry_msgs::PoseStamped final_goal;
        if (computeFinalGoal(object_pose_map_, final_goal))
        {
            move_base_msgs::MoveBaseGoal mb_goal;
            mb_goal.target_pose = final_goal;
            ac_.sendGoal(mb_goal);
            // 使用 tf::getYaw 替代 tf2::getYaw
            ROS_INFO_THROTTLE(1.0, "Sending final approach goal: (%.2f, %.2f, yaw=%.2f)",
                              final_goal.pose.position.x,
                              final_goal.pose.position.y,
                              tf::getYaw(final_goal.pose.orientation));
        }
    }
    else
    {
        geometry_msgs::PoseStamped explore_goal;
        if (findFrontier(explore_goal))
        {
            move_base_msgs::MoveBaseGoal mb_goal;
            mb_goal.target_pose = explore_goal;
            ac_.sendGoal(mb_goal);
            ROS_INFO_THROTTLE(2.0, "Sending exploration goal: (%.2f, %.2f)",
                              explore_goal.pose.position.x,
                              explore_goal.pose.position.y);
        }
        else
        {
            ROS_INFO_THROTTLE(5.0, "No frontier found, robot may rotate or wait.");
        }
    }
}

bool NavigationDriver::computeFinalGoal(const geometry_msgs::Pose& object_map,
                                        geometry_msgs::PoseStamped& goal)
{
    geometry_msgs::TransformStamped tf;
    try
    {
        tf = tf_buffer_.lookupTransform("map", "base_link", ros::Time(0));
    }
    catch (tf2::TransformException &ex)
    {
        ROS_WARN("Could not get robot pose: %s", ex.what());
        return false;
    }

    double robot_x = tf.transform.translation.x;
    double robot_y = tf.transform.translation.y;
    // robot_yaw 不再需要，故删除原无用代码

    double obj_x = object_map.position.x;
    double obj_y = object_map.position.y;

    double angle_to_obj = atan2(obj_y - robot_y, obj_x - robot_x);

    double goal_x = obj_x - stop_distance_ * cos(angle_to_obj);
    double goal_y = obj_y - stop_distance_ * sin(angle_to_obj);

    double goal_yaw = atan2(obj_y - goal_y, obj_x - goal_x);

    goal.header.frame_id = "map";
    goal.header.stamp = ros::Time::now();
    goal.pose.position.x = goal_x;
    goal.pose.position.y = goal_y;
    goal.pose.position.z = 0.0;
    tf2::Quaternion q;
    q.setRPY(0, 0, goal_yaw);
    goal.pose.orientation = tf2::toMsg(q);
    return true;
}

bool NavigationDriver::findFrontier(geometry_msgs::PoseStamped& goal)
{
    if (!map_received_)
        return false;

    int w = current_map_.info.width;
    int h = current_map_.info.height;
    double res = current_map_.info.resolution;
    double ox = current_map_.info.origin.position.x;
    double oy = current_map_.info.origin.position.y;

    double robot_x, robot_y;
    try
    {
        geometry_msgs::TransformStamped tf = tf_buffer_.lookupTransform("map", "base_link", ros::Time(0));
        robot_x = tf.transform.translation.x;
        robot_y = tf.transform.translation.y;
    }
    catch (...)
    {
        return false;
    }

    std::vector<std::pair<int,int>> frontiers;
    for (int y = 1; y < h-1; ++y)
    {
        for (int x = 1; x < w-1; ++x)
        {
            int idx = y * w + x;
            if (current_map_.data[idx] == -1)
            {
                if (current_map_.data[idx-1] == 0 || current_map_.data[idx+1] == 0 ||
                    current_map_.data[idx-w] == 0 || current_map_.data[idx+w] == 0)
                {
                    frontiers.push_back(std::make_pair(x,y));
                }
            }
        }
    }

    if (frontiers.empty())
        return false;

    double best_dist = std::numeric_limits<double>::max();
    int best_x = -1, best_y = -1;
    for (auto& f : frontiers)
    {
        double wx = ox + (f.first + 0.5) * res;
        double wy = oy + (f.second + 0.5) * res;
        double d = distance(robot_x, robot_y, wx, wy);
        if (d > frontier_min_dist_ && d < best_dist)
        {
            best_dist = d;
            best_x = f.first;
            best_y = f.second;
        }
    }

    if (best_x < 0)
        return false;

    double gx = ox + (best_x + 0.5) * res;
    double gy = oy + (best_y + 0.5) * res;
    goal.header.frame_id = "map";
    goal.header.stamp = ros::Time::now();
    goal.pose.position.x = gx;
    goal.pose.position.y = gy;
    goal.pose.position.z = 0.0;
    goal.pose.orientation = tf2::toMsg(tf2::Quaternion::getIdentity());
    return true;
}

double NavigationDriver::distance(double x1, double y1, double x2, double y2)
{
    return sqrt(pow(x1-x2, 2) + pow(y1-y2, 2));
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "navigation_driver");
    ros::NodeHandle nh("~");
    NavigationDriver driver(nh);
    ros::spin();
    return 0;
}