#ifndef MY_NAVIGATION_H
#define MY_NAVIGATION_H

#include <ros/ros.h>
#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/OccupancyGrid.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <tf/transform_datatypes.h>
#include <vector>
#include <mutex>
class NavigationDriver
{
public:
    NavigationDriver(ros::NodeHandle& nh);
    ~NavigationDriver();
private:
    void objectCallback(const geometry_msgs::PoseStampedConstPtr& msg);
    void mapCallback(const nav_msgs::OccupancyGridConstPtr& msg);
    void timerCallback(const ros::TimerEvent& event);
    bool findFrontier(geometry_msgs::PoseStamped& goal);
    double distance(double x1, double y1, double x2, double y2);
    bool computeFinalGoal(const geometry_msgs::Pose& object_map,
                          geometry_msgs::PoseStamped& goal);
    ros::NodeHandle nh_;
    ros::Subscriber object_sub_;
    ros::Subscriber map_sub_;
    ros::Timer explore_timer_;
    actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> ac_;
    tf2_ros::Buffer tf_buffer_;
    tf2_ros::TransformListener tf_listener_;
    nav_msgs::OccupancyGrid current_map_;
    bool map_received_;
    bool object_found_;
    geometry_msgs::Pose object_pose_map_;
    ros::Time last_object_time_;
    double object_timeout_;
    std::mutex data_mutex_;
    double camera_offset_x_;
    double stop_distance_;
    double exploration_frequency_;
    double frontier_min_dist_;
};

#endif